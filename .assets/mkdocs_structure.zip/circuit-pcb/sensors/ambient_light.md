# Ambient Light
